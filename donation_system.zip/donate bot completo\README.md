# Donation Bot 🤖

A Discord bot for managing donations with PIX integration.

## 🌍 Languages / Idiomas / Langues / 言語

- [English](#english)
- [Português](#português)
- [Español](#español)
- [Français](#français)
- [日本語](#日本語)

---

## English

### Installation

1. Clone the repository:
```bash
git clone [repository-url]
cd donate-bot-completo
```

2. Install dependencies:
```bash
npm install
```

3. Configure environment variables:
   - Copy `.env.example` to `.env`
   - Fill in the required values:
     - `DISCORD_TOKEN`: Your Discord bot token
     - `PIXGG_URL`: PIX checkout API URL
     - `STREAMER_ID`: Your streamer ID
     - `LOGS_CHANNEL_ID`: Channel ID for donation logs
     - `API_URL`: API URL for donation verification

4. Start the bot:
```bash
node index.js
```

### Usage

1. Use the `/donate` command in your Discord server
2. Follow the prompts to make a donation
3. The bot will generate a PIX QR code or copy-paste code
4. After payment, the bot will automatically verify and assign roles

---

## Português

### Instalação

1. Clone o repositório:
```bash
git clone [url-do-repositorio]
cd donate-bot-completo
```

2. Instale as dependências:
```bash
npm install
```

3. Configure as variáveis de ambiente:
   - Copie `.env.example` para `.env`
   - Preencha os valores necessários:
     - `DISCORD_TOKEN`: Token do seu bot do Discord
     - `PIXGG_URL`: URL da API de checkout PIX
     - `STREAMER_ID`: Seu ID de streamer
     - `LOGS_CHANNEL_ID`: ID do canal para logs de doações
     - `API_URL`: URL da API para verificação de doações

4. Inicie o bot:
```bash
node index.js
```

### Como Usar

1. Use o comando `/donate` no seu servidor Discord
2. Siga as instruções para fazer uma doação
3. O bot irá gerar um código QR PIX ou código para copiar e colar
4. Após o pagamento, o bot verificará automaticamente e atribuirá os cargos

---

## Español

### Instalación

1. Clona el repositorio:
```bash
git clone [url-del-repositorio]
cd donate-bot-completo
```

2. Instala las dependencias:
```bash
npm install
```

3. Configura las variables de entorno:
   - Copia `.env.example` a `.env`
   - Completa los valores requeridos:
     - `DISCORD_TOKEN`: Token de tu bot de Discord
     - `PIXGG_URL`: URL de la API de checkout PIX
     - `STREAMER_ID`: Tu ID de streamer
     - `LOGS_CHANNEL_ID`: ID del canal para logs de donaciones
     - `API_URL`: URL de la API para verificación de donaciones

4. Inicia el bot:
```bash
node index.js
```

### Uso

1. Usa el comando `/donate` en tu servidor de Discord
2. Sigue las instrucciones para hacer una donación
3. El bot generará un código QR PIX o código para copiar y pegar
4. Después del pago, el bot verificará automáticamente y asignará los roles

---

## Français

### Installation

1. Clonez le dépôt :
```bash
git clone [url-du-depot]
cd donate-bot-completo
```

2. Installez les dépendances :
```bash
npm install
```

3. Configurez les variables d'environnement :
   - Copiez `.env.example` vers `.env`
   - Remplissez les valeurs requises :
     - `DISCORD_TOKEN`: Token de votre bot Discord
     - `PIXGG_URL`: URL de l'API de paiement PIX
     - `STREAMER_ID`: Votre ID de streamer
     - `LOGS_CHANNEL_ID`: ID du canal pour les logs de dons
     - `API_URL`: URL de l'API pour la vérification des dons

4. Démarrez le bot :
```bash
node index.js
```

### Utilisation

1. Utilisez la commande `/donate` sur votre serveur Discord
2. Suivez les instructions pour faire un don
3. Le bot générera un code QR PIX ou un code à copier-coller
4. Après le paiement, le bot vérifiera automatiquement et attribuera les rôles

---

## 日本語

### インストール

1. リポジトリをクローン:
```bash
git clone [リポジトリURL]
cd donate-bot-completo
```

2. 依存関係をインストール:
```bash
npm install
```

3. 環境変数を設定:
   - `.env.example` を `.env` にコピー
   - 必要な値を入力:
     - `DISCORD_TOKEN`: Discordボットのトークン
     - `PIXGG_URL`: PIX決済APIのURL
     - `STREAMER_ID`: ストリーマーID
     - `LOGS_CHANNEL_ID`: 寄付ログ用チャンネルID
     - `API_URL`: 寄付確認用APIのURL

4. ボットを起動:
```bash
node index.js
```

### 使い方

1. Discordサーバーで `/donate` コマンドを使用
2. 寄付の手順に従う
3. ボットがPIX QRコードまたはコピー＆ペースト用コードを生成
4. 支払い後、ボットが自動的に確認し、ロールを付与

---

## 🤝 Contributing

Feel free to contribute to this project by submitting issues or pull requests.

## 📝 License

This project is licensed under the MIT License - see the LICENSE file for details. 