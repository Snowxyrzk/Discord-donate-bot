# 💰 Sistema de Doações Discord com PIX

<div align="center">
  <img src="https://img.shields.io/badge/Discord-7289DA?style=for-the-badge&logo=discord&logoColor=white" alt="Discord">
  <img src="https://img.shields.io/badge/Node.js-43853D?style=for-the-badge&logo=node.js&logoColor=white" alt="Node.js">
  <img src="https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black" alt="JavaScript">
</div>

## 📋 Índice
<details>
  <summary>Clique para expandir</summary>
  
  - [Sobre o Projeto](#-sobre-o-projeto)
  - [Componentes do Sistema](#-componentes-do-sistema)
  - [Instalação](#-instalação)
  - [Como Usar](#-como-usar)
  - [Funcionalidades](#-funcionalidades)
  - [Segurança](#-segurança)
  - [Logs](#-logs)
  - [Importante](#-importante)
  - [Suporte](#-suporte)
  - [Licença](#-licença)
</details>

## 🎯 Sobre o Projeto
<details>
  <summary>Clique para expandir</summary>
  
  Este é um sistema completo de doações para Discord que utiliza a API do PIX GG para processar pagamentos. O sistema foi desenvolvido para facilitar o processo de doações e gerenciamento de cargos em servidores Discord.
  
  ### Características Principais
  - Interface intuitiva e amigável
  - Sistema automático de cargos
  - Verificação em tempo real de pagamentos
  - Suporte a QR Code e PIX
  - Sistema completo de logs
</details>

## 🛠️ Componentes do Sistema
<details>
  <summary>Clique para expandir</summary>
  
  ### 1. Bot Discord
  - Interface interativa para doações
  - Sistema de cargos automáticos
  - Verificação automática de pagamentos
  - QR Code e código PIX
  - Sistema de logs
  
  ### 2. API de Verificação
  - Verificação em tempo real
  - Integração com PIX GG
  - Sistema de autenticação seguro
  - Logs de transações
</details>

## 📦 Instalação
<details>
  <summary>Clique para expandir</summary>
  
  ### Pré-requisitos
  ```bash
  - Node.js (v14+)
  - npm ou yarn
  - Conta PIX GG
  - Bot Discord
  ```
  
  ### Configuração do Bot
  ```bash
  # Clone o repositório
  git clone [URL_DO_REPOSITORIO]
  
  # Instale as dependências
  cd "donate bot completo"
  npm install
  
  # Configure o .env
  cp .env.example .env
  ```
  
  ### Variáveis de Ambiente
  ```env
  # Bot Discord
  DISCORD_TOKEN=seu_token
  PIXGG_URL=sua_url
  STREAMER_ID=seu_id
  LOGS_CHANNEL_ID=id_canal
  API_URL=url_api
  
  # Cargos
  BASIC_ROLE_ID=id_basic
  PLUS_ROLE_ID=id_plus
  PRO_ROLE_ID=id_pro
  TEST_ROLE_ID=id_teste
  ```
</details>

## 🚀 Como Usar
<details>
  <summary>Clique para expandir</summary>
  
  ### Comandos do Bot
  ```bash
  /donate - Inicia processo de doação
  !verificar [token] - Verifica status da doação
  ```
  
  ### Processo de Doação
  1. Use `/donate`
  2. Escolha o valor
  3. Escaneie QR Code
  4. Aguarde confirmação
  5. Receba o cargo automaticamente
</details>

## ⚙️ Funcionalidades
<details>
  <summary>Clique para expandir</summary>
  
  ### Sistema de Cargos
  | Cargo | Valor | Duração | Recursos |
  |-------|-------|---------|----------|
  | Basic | R$5 | 30 dias | Reações, anexos, scripts |
  | Plus | R$10 | 30 dias | Basic + transmissão |
  | Pro | R$15 | 30 dias | Plus + suporte |
  | Teste | R$0.10 | 30 dias | Recursos básicos |
</details>

## 🔒 Segurança
<details>
  <summary>Clique para expandir</summary>
  
  ### Medidas de Segurança
  - Credenciais em variáveis de ambiente
  - Autenticação com tokens
  - Verificação em tempo real
  - Logs detalhados
  
  ### Boas Práticas
  - Mantenha .env seguro
  - Faça backups regulares
  - Monitore transações
  - Atualize regularmente
</details>

## 📝 Logs
<details>
  <summary>Clique para expandir</summary>
  
  ### Sistema de Logs
  - Registro em JSON
  - Data e hora
  - Valor e usuário
  - Status da transação
  
  ### Estrutura do Log
  ```json
  {
    "date": "2024-03-08T12:00:00",
    "user": "123456789",
    "amount": 10.00,
    "status": "confirmed"
  }
  ```
</details>

## ⚠️ Importante
<details>
  <summary>Clique para expandir</summary>
  
  ### Avisos
  - Projeto privado
  - Não compartilhe credenciais
  - Faça backups
  - Monitore regularmente
  
  ### Manutenção
  - Verifique logs diariamente
  - Atualize dependências
  - Teste regularmente
  - Mantenha documentação atualizada
</details>

## 🤝 Suporte
<details>
  <summary>Clique para expandir</summary>
  
  ### Contato
  - [Snow](https://e-z.bio/im_snow)
  - [iUnknowbr](https://e-z.bio/iUnknownBr)
  
  ### Canais de Suporte
  - Discord: [Servidor de Suporte](link_do_servidor)
  - Email: suporte@exemplo.com
</details>

## 📄 Licença
<details>
  <summary>Clique para expandir</summary>
  
  Este projeto é privado e não deve ser compartilhado ou distribuído sem autorização expressa dos desenvolvedores.
  
  ### Termos de Uso
  - Uso pessoal apenas
  - Não redistribuir
  - Não modificar sem autorização
  - Manter créditos originais
</details>

---

<div align="center">
  <p>Desenvolvido com ❤️ por <a href="https://e-z.bio/im_snow">Snow</a> e <a href="https://e-z.bio/iUnknownBr">iUnknowbr</a></p>
</div> 