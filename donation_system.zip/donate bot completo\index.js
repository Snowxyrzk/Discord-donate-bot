const { Client, GatewayIntentBits, EmbedBuilder, ActionRowBuilder, ButtonBuilder, ModalBuilder, TextInputBuilder, TextInputStyle, SlashCommandBuilder } = require('discord.js');
require('dotenv').config();
const axios = require('axios');
const QRCode = require('qrcode');
const crypto = require('crypto');
const fs = require('fs');
const path = require('path');

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
  ],
});

const PIXGG_URL = process.env.PIXGG_URL;
const STREAMER_ID = process.env.STREAMER_ID;
const LOGS_CHANNEL_ID = process.env.LOGS_CHANNEL_ID;
const API_URL = process.env.API_URL;
const LOGS_FILE = path.join(__dirname, 'donation_logs.json');
const DONATES_FILE = path.join(__dirname, 'donates.json');

const userData = new Map();
const pendingDonations = new Map();

let donationLogs = [];
if (fs.existsSync(LOGS_FILE)) {
  donationLogs = JSON.parse(fs.readFileSync(LOGS_FILE, 'utf-8'));
}

// Carrega ou inicializa o arquivo de doações com expiração
let activeDonations = {};
if (fs.existsSync(DONATES_FILE)) {
  activeDonations = JSON.parse(fs.readFileSync(DONATES_FILE, 'utf-8'));
} else {
  fs.writeFileSync(DONATES_FILE, JSON.stringify({}, null, 2));
}

function generateRandomToken() {
  return crypto.randomBytes(16).toString('hex');
}

// Função obfuscada para gerar créditos com tratamento de erro
function getCredits() {
  try {
    const credits = {
      a: 'iUnknowbr',
      b: '@https://e-z.bio/iUnknownBr',
      c: '! Im Snow? :ez:',
      d: 'https://e-z.bio/im_snow'
    };
    
    const obfuscated = Buffer.from(JSON.stringify(credits)).toString('base64');
    const decoded = JSON.parse(Buffer.from(obfuscated, 'base64').toString());
    
    return `${decoded.a} ${decoded.b}\n${decoded.c} ${decoded.d}`;
  } catch (error) {
    console.error('Error generating credits:', error);
    return 'Credits by iUnknowbr & Snow';
  }
}

async function sendDonationLog(donation) {
  try {
    donation.credits = getCredits();
    donationLogs.push(donation);
    fs.writeFileSync(LOGS_FILE, JSON.stringify(donationLogs, null, 2));
    console.log(`Doação registrada: ${JSON.stringify(donation)}`);
    return true;
  } catch (error) {
    console.error('Erro ao salvar log de doação:', error);
    return false;
  }
}

// Helper function to get Brasilia timezone date
function getBrasiliaDate() {
  const date = new Date();
  return new Date(date.toLocaleString('en-US', { timeZone: 'America/Sao_Paulo' }));
}

// Save donation with expiration date
async function saveDonationWithExpiration(userId, roleId, amount) {
  try {
    // Calculate expiration date (30 days from now)
    const startDate = getBrasiliaDate();
    const expirationDate = new Date(startDate);
    expirationDate.setDate(expirationDate.getDate() + 30);
    
    // Create donation entry
    activeDonations[userId] = {
      userId,
      roleId,
      amount,
      startDate: startDate.toISOString(),
      expirationDate: expirationDate.toISOString(),
      active: true
    };
    
    // Save to file
    fs.writeFileSync(DONATES_FILE, JSON.stringify(activeDonations, null, 2));
    console.log(`Doação com expiração registrada para usuário ${userId}, cargo ${roleId}`);
    return true;
  } catch (error) {
    console.error('Erro ao salvar doação com expiração:', error);
    return false;
  }
}

// Removendo os IDs de cargo fixos
const roles = {
  [process.env.BASIC_ROLE_ID]: parseFloat(process.env.BASIC_ROLE_AMOUNT || '5'),
  [process.env.PLUS_ROLE_ID]: parseFloat(process.env.PLUS_ROLE_AMOUNT || '10'),
  [process.env.PRO_ROLE_ID]: parseFloat(process.env.PRO_ROLE_AMOUNT || '15'),
  [process.env.TEST_ROLE_ID]: parseFloat(process.env.TEST_ROLE_AMOUNT || '0.10')
};

async function assignRoleBasedOnDonation(userId, amount) {
  const guild = client.guilds.cache.first();
  if (!guild) return;

  const member = await guild.members.fetch(userId).catch(console.error);
  if (!member) return;

  let closestRoleId = null;
  let smallestDifference = Infinity;

  for (const [roleId, roleAmount] of Object.entries(roles)) {
    const difference = Math.abs(amount - roleAmount);
    if (difference < smallestDifference) {
      smallestDifference = difference;
      closestRoleId = roleId;
    }
  }

  if (!closestRoleId) return;

  // Adiciona o novo cargo primeiro
  await member.roles.add(closestRoleId).catch(console.error);

  // Remove todos os cargos de doação existentes, exceto o novo
  for (const roleId of Object.keys(roles)) {
    if (roleId !== closestRoleId && member.roles.cache.has(roleId)) {
      await member.roles.remove(roleId).catch(console.error);
    }
  }

  // Salva a doação com data de expiração
  await saveDonationWithExpiration(userId, closestRoleId, amount);
}

// Verificação periódica de cargos expirados (a cada 5 horas)
function checkExpiredRoles() {
  console.log("Verificando cargos expirados...");
  const now = getBrasiliaDate();
  
  for (const userId in activeDonations) {
    const donation = activeDonations[userId];
    
    // Ignora doações já inativas
    if (!donation.active) continue;
    
    const expirationDate = new Date(donation.expirationDate);
    
    // Se a data de expiração já passou
    if (now > expirationDate) {
      console.log(`Cargo expirado para usuário ${userId}, cargo ${donation.roleId}`);
      
      // Remove o cargo
      const guild = client.guilds.cache.first();
      if (guild) {
        guild.members.fetch(userId)
          .then(member => {
            member.roles.remove(donation.roleId)
              .then(() => console.log(`Cargo ${donation.roleId} removido do usuário ${userId}`))
              .catch(error => console.error(`Erro ao remover cargo ${donation.roleId} do usuário ${userId}:`, error));
            
            // Marca como inativo no arquivo
            activeDonations[userId].active = false;
            fs.writeFileSync(DONATES_FILE, JSON.stringify(activeDonations, null, 2));
          })
          .catch(error => console.error(`Erro ao buscar membro ${userId}:`, error));
      }
    }
  }
}

function startDonationVerification(token) {
  const verificationInterval = setInterval(async () => {
    const donationData = pendingDonations.get(token);
    if (!donationData) {
      clearInterval(verificationInterval);
      return;
    }

    try {
      const response = await axios.post(API_URL, {
        donatorNickName: token,
      });

      if (response.data && response.data.message.includes('Doação encontrada')) {
        console.log(`Doação confirmada para token: ${token}`);

        const donationInfo = {
          userId: donationData.userId,
          donatorNickname: donationData.donatorNickname || response.data.donation.donatorNickname,
          totalAmount: response.data.donation.totalAmount,
          token: token,
        };

        await sendDonationLog(donationInfo);
        await assignRoleBasedOnDonation(donationData.userId, response.data.donation.totalAmount);

        const user = await client.users.fetch(donationData.userId);
        if (user) {
          const confirmationEmbed = new EmbedBuilder()
            .setTitle('🎉 Doação Confirmada!')
            .setDescription(`Sua doação de R$ ${response.data.donation.totalAmount} foi confirmada com sucesso. Muito obrigado pelo seu apoio! Seu cargo foi entregue.\n\n` + getCredits())
            .setColor('#7e5ee7');

          user.send({ embeds: [confirmationEmbed] }).catch(e => console.error('Não foi possível enviar DM:', e));
        }

        pendingDonations.delete(token);
        clearInterval(verificationInterval);
      }
    } catch (error) {
      console.error(`Erro ao verificar doação para token ${token}:`, error.message);
    }
  }, 10000); // Verifica a cada 10 segundos

  // Timeout após 15 minutos
  setTimeout(() => {
    clearInterval(verificationInterval);
    const donationData = pendingDonations.get(token);
    if (donationData) {
      console.log(`Doação cancelada por timeout para token: ${token}`);

      client.users.fetch(donationData.userId)
        .then(user => {
          const timeoutEmbed = new EmbedBuilder()
            .setTitle('❌ Doação Cancelada')
            .setDescription('O tempo limite de 15 minutos para confirmar sua doação expirou e a transação foi cancelada.')
            .addFields(
              { name: 'Valor', value: `R$ ${donationData.amount}`, inline: true },
              { name: 'Token', value: token, inline: true }
            )
            .setColor('#7e5ee7')
            .setFooter({ text: 'Caso tenha realizado o pagamento, entre em contato com o suporte.' })
            .setTimestamp();

          user.send({ embeds: [timeoutEmbed] }).catch(e =>
            console.error('Não foi possível enviar notificação de cancelamento:', e)
          );
        })
        .catch(e => console.error('Não foi possível encontrar o usuário para notificação de cancelamento:', e));

      pendingDonations.delete(token);
    }
  }, 900000); // 15 minutos em milissegundos
}

const donateCommand = new SlashCommandBuilder()
  .setName('donate')
  .setDescription('Inicie o processo de doação.');

client.once('ready', () => {
  console.log(`Bot está online: ${client.user.tag}`);

  client.application.commands.create(donateCommand)
    .then(() => console.log('Comando /donate registrado com sucesso!'))
    .catch(console.error);
    
  // Inicia verificação de cargos expirados a cada 5 horas
  checkExpiredRoles(); // Verifica imediatamente ao iniciar
  setInterval(checkExpiredRoles, 5 * 60 * 60 * 1000); // 5 hours in milliseconds
});

client.on('interactionCreate', async interaction => {
  if (interaction.isCommand() && interaction.commandName === 'donate') {
    const firstEmbed = new EmbedBuilder()
      .setColor('#7e5ee7')
      .setDescription('Use o botão abaixo para iniciar o processo de doação.');

    const donateButton = new ButtonBuilder()
      .setCustomId('doar_button')
      .setLabel('Fazer uma Doação')
      .setStyle('Secondary')
      .setEmoji('💜');

    const row = new ActionRowBuilder().addComponents(donateButton);

    await interaction.channel.send({ embeds: [firstEmbed], components: [row] });

    await interaction.reply({ content: 'Embed de doação enviada com sucesso!', ephemeral: true });
  }

  if (interaction.isButton() && interaction.customId === 'doar_button') {
    const modal = new ModalBuilder()
      .setCustomId('doar_modal')
      .setTitle('Formulário de Doação');

    const amountInput = new TextInputBuilder()
      .setCustomId('amount')
      .setLabel('Valor da Doação (mínimo R$ 1,00)')
      .setStyle(TextInputStyle.Short);

    const actionRow = new ActionRowBuilder().addComponents(amountInput);

    modal.addComponents(actionRow);

    await interaction.showModal(modal);
  }

  if (interaction.isModalSubmit() && interaction.customId === 'doar_modal') {
    const amount = interaction.fields.getTextInputValue('amount');

    const formattedAmount = parseFloat(amount.replace(',', '.'));

    if (isNaN(formattedAmount) || formattedAmount < 1.00) {
      return interaction.reply({
        content: '💜 **O valor mínimo para doação é R$ 1,00.**\nPor favor, insira um valor igual ou superior a R$ 1 real.',
        ephemeral: true,
      });
    }

    const donationToken = generateRandomToken();

    const data = {
      streamerId: STREAMER_ID,
      donatorNickname: donationToken,
      donatorMessage: 'Affes',
      donatorAmount: formattedAmount,
      minimumDonateAmount: null,
      fileId: null,
    };

    try {
      const response = await axios.post(PIXGG_URL, data, {
        headers: {
          'Content-Type': 'application/json',
          'Authorization': 'Bearer null',
          'Accept-Language': 'pt-BR,pt;q=0.9',
          'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/133.0.0.0 Safari/537.36',
          'Accept': 'application/json, text/plain, */*',
          'Origin': 'https://pixgg.com',
          'Sec-Fetch-Site': 'same-site',
          'Sec-Fetch-Mode': 'cors',
          'Sec-Fetch-Dest': 'empty',
          'Referer': 'https://pixgg.com/',
          'Accept-Encoding': 'gzip, deflate, br',
          'Priority': 'u=4, i',
        },
      });

      const { pixUrl } = response.data;

      userData.set(interaction.user.id, { pixUrl, userId: interaction.user.id });

      pendingDonations.set(donationToken, {
        userId: interaction.user.id,
        amount: formattedAmount,
        donatorNickname: interaction.user.username,
      });

      startDonationVerification(donationToken);

      const embed = new EmbedBuilder()
        .setTitle('Realizar Doação')
        .setDescription(
          '💜 **Obrigado por doar!**\n' +
          'Sua contribuição é essencial para o desenvolvimento de novos scripts, bots, sites e muito mais. Com seu apoio, podemos continuar trazendo inovações e melhorias para a comunidade. 💜\n\n' +
          'Clique nos botões abaixo para acessar o QR Code ou copiar o código PIX.\n\n' +
          getCredits()
        )
        .setColor('#7e5ee7');

      const row = new ActionRowBuilder()
        .addComponents(
          new ButtonBuilder()
            .setCustomId('qr_code')
            .setLabel('QR Code')
            .setStyle('Secondary')
            .setEmoji('📷'),
          new ButtonBuilder()
            .setCustomId('pix_copy')
            .setLabel('PIX Copia e Cola')
            .setStyle('Secondary')
            .setEmoji('📋'),
        );

      await interaction.reply({ embeds: [embed], components: [row], ephemeral: true });

      await interaction.followUp({
        content: `**Seu código de acompanhamento:** \`${donationToken}\`\n*Guarde este código para verificar o status da sua doação.*`,
        ephemeral: true,
      });
    } catch (error) {
      console.error('Erro ao processar a doação:', error);
      await interaction.reply({ content: 'Ocorreu um erro ao processar sua doação. Tente novamente mais tarde.', ephemeral: true });
    }
  }

  if (interaction.isButton() && interaction.customId === 'qr_code') {
    const userPixData = userData.get(interaction.user.id);

    if (!userPixData?.pixUrl) {
      return interaction.reply({ content: 'Não foi possível encontrar o código PIX. Tente novamente.', ephemeral: true });
    }

    QRCode.toDataURL(userPixData.pixUrl, (err, qrCodeImageUrl) => {
      if (err) {
        console.error('Erro ao gerar o QR Code:', err);
        return interaction.reply({ content: 'Ocorreu um erro ao gerar o QR Code. Tente novamente mais tarde.', ephemeral: true });
      }

      interaction.reply({
        files: [{
          attachment: Buffer.from(qrCodeImageUrl.split(',')[1], 'base64'),
          name: 'qrcode.png',
        }],
        ephemeral: true,
      });
    });
  }

  if (interaction.isButton() && interaction.customId === 'pix_copy') {
    const userPixData = userData.get(interaction.user.id);

    if (!userPixData?.pixUrl) {
      return interaction.reply({ content: 'Não foi possível encontrar o código PIX. Tente novamente.', ephemeral: true });
    }

    await interaction.reply({ content: userPixData.pixUrl, ephemeral: true });
  }
});

client.on('messageCreate', async message => {
  if (message.content.startsWith('!verificar')) {
    const args = message.content.split(' ');
    if (args.length < 2) {
      return message.reply('Por favor, forneça o token da sua doação: `!verificar [token]`');
    }

    const token = args[1];

    if (pendingDonations.has(token)) {
      const donation = pendingDonations.get(token);
      return message.reply(`Sua doação de R$ ${donation.amount} está sendo processada. Aguarde a confirmação.`);
    } else {
      try {
        const response = await axios.post(API_URL, {
          donatorNickName: token,
        });

        if (response.data && response.data.message.includes('Doação encontrada')) {
          return message.reply(`🎉 Sua doação de R$ ${response.data.donation.totalAmount} foi confirmada! **Desenvolvido por: !im Snow?**`);
        } else {
          return message.reply('Não foi possível encontrar uma doação com este token. Verifique se o token está correto.');
        }
      } catch (error) {
        console.error('Erro ao verificar doação:', error);
        return message.reply('Ocorreu um erro ao verificar sua doação. Tente novamente mais tarde.');
      }
    }
  }
});

client.login(process.env.DISCORD_TOKEN);