# Sistema de Doações Discord com PIX

## 📋 Sobre o Projeto
Este é um sistema completo de doações para Discord que utiliza a API do PIX GG para processar pagamentos. O sistema inclui um bot Discord e uma API de verificação de doações.

## 🛠️ Componentes do Sistema

### 1. Bot Discord
- Interface interativa para doações
- Sistema de cargos automáticos baseado em doações
- Verificação automática de pagamentos
- QR Code e código PIX para pagamento
- Sistema de logs de doações

### 2. API de Verificação
- Verificação de doações em tempo real
- Integração com PIX GG
- Sistema de autenticação seguro
- Logs de transações

## 📦 Instalação

### Pré-requisitos
- Node.js (versão 14 ou superior)
- npm ou yarn
- Conta no PIX GG
- Bot Discord configurado

### Configuração do Bot Discord
1. Clone o repositório
2. Instale as dependências:
```bash
cd "donate bot completo"
npm install
```
3. Configure o arquivo `.env`:
```
DISCORD_TOKEN=seu_token_do_bot
PIXGG_URL=sua_url_do_pixgg
STREAMER_ID=seu_id_do_streamer
LOGS_CHANNEL_ID=id_do_canal_de_logs
API_URL=url_da_api
BASIC_ROLE_ID=id_do_cargo_basic
PLUS_ROLE_ID=id_do_cargo_plus
PRO_ROLE_ID=id_do_cargo_pro
TEST_ROLE_ID=id_do_cargo_teste
```

### Configuração da API
1. Navegue até a pasta da API:
```bash
cd "api pix gg"
npm install
```
2. Configure o arquivo `.env`:
```
LOGIN_URL=sua_url_de_login
DONATIONS_URL=sua_url_de_doacoes
EMAIL=seu_email
PASSWORD=sua_senha
```

## 🚀 Como Usar

### No Discord
1. Use o comando `/donate` para iniciar o processo de doação
2. Escolha o valor da doação
3. Escaneie o QR Code ou use o código PIX
4. Após o pagamento, o cargo será atribuído automaticamente

### Verificação de Doações
- Use o comando `!verificar [token]` para verificar o status de uma doação
- O sistema verifica automaticamente a cada 10 segundos

## ⚙️ Funcionalidades

### Sistema de Cargos
- Cargo Basic: R$5 (30 dias)
- Cargo Plus: R$10 (30 dias)
- Cargo Pro: R$15 (30 dias)
- Cargo de Teste: R$0.10

### Recursos dos Cargos
- Basic: Reações, anexos, scripts sem encurtadores, mensagens de voz
- Plus: Todos os recursos do Basic + transmissão de tela
- Pro: Todos os recursos do Plus + suporte preferencial

## 🔒 Segurança
- Todas as credenciais são armazenadas em variáveis de ambiente
- Sistema de autenticação seguro com tokens
- Verificação em tempo real de pagamentos
- Logs de todas as transações

## 📝 Logs
- Todas as doações são registradas em arquivos JSON
- Logs incluem data, valor, usuário e status
- Sistema de backup automático

## ⚠️ Importante
- Mantenha seu arquivo `.env` seguro
- Não compartilhe suas credenciais
- Faça backup regular dos logs
- Monitore as doações regularmente

## 🤝 Suporte
Para suporte ou dúvidas, entre em contato através do Discord:
- [Snow](https://e-z.bio/im_snow)
- [iUnknowbr](https://e-z.bio/iUnknownBr)

## 📄 Licença
Este projeto é privado e não deve ser compartilhado ou distribuído sem autorização. 