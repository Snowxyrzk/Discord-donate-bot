const express = require('express');
const bodyParser = require('body-parser');
const axios = require('axios');
const { wrapper } = require('axios-cookiejar-support');
const { CookieJar } = require('tough-cookie');

const app = express();
app.use(bodyParser.json());

// Configurações atualizadas
const config = {
  loginUrl: process.env.LOGIN_URL,
  donationsUrl: process.env.DONATIONS_URL,
  credentials: {
    email: process.env.EMAIL,
    password: process.env.PASSWORD
  },
  checkInterval: 1000
};

const jar = new CookieJar();
const client = wrapper(axios.create({ jar }));

// Headers atualizados com suporte a Authorization
let headers = {
  'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
  'Content-Type': 'application/json',
  'Origin': 'https://app.pixgg.com',
  'Referer': 'https://app.pixgg.com/users/login'
};

async function login() {
  try {
    const response = await client.post(config.loginUrl, {
      email: config.credentials.email,
      password: config.credentials.password
    }, { headers });

    console.log('Resposta completa:', JSON.stringify(response.data, null, 2));
    
    // Verificação corrigida usando username
    if (response.data.username === 'Kontra') {
      console.log('✅ Login bem-sucedido!');
      
      // Adiciona o token JWT aos headers
      headers = {
        ...headers,
        'Authorization': `Bearer ${response.data.authToken}`
      };
      
      return true;
    }
    
    console.log('❌ Falha na validação do login');
    return false;
    
  } catch (error) {
    console.error('🔥 Erro no login:', error.response?.data || error.message);
    return false;
  }
}

async function checkDonations(donatorNickName) {
  try {
    const params = {
      page: 1,
      pageSize: 10,
      donatorNickName: donatorNickName
    };

    const response = await client.get(config.donationsUrl, {
      headers,
      params
    });

    console.log('Resposta das doações:', JSON.stringify(response.data, null, 2));
    
    if (response.data.length > 0) {
      // Retorna os detalhes da primeira doação encontrada
      const donation = response.data[0];
      return {
        date: donation.date, // Exemplo: "2025-03-08T22:54:49.167587"
        totalAmount: donation.totalAmount,
        donatorMessage: donation.donatorMessage,
        donatorNickname: donation.donatorNickname
      };
    }
    
    return null; // Retorna null se não houver doações
    
  } catch (error) {
    console.error('Erro na verificação:', error.response?.data || error.message);
    return null;
  }
}

// Rota da API
app.post('/check-donation', async (req, res) => {
  const { donatorNickName } = req.body;

  if (!donatorNickName) {
    return res.status(400).json({ error: 'O campo donatorNickName é obrigatório.' });
  }

  if (!await login()) {
    return res.status(500).json({ error: 'Falha no login.' });
  }

  const donationDetails = await checkDonations(donatorNickName);

  if (donationDetails) {
    return res.json({
      message: '🎉 Doação encontrada!',
      donation: donationDetails,
      credits: '[Snow](@https://e-z.bio/im_snow)'
    });
  } else {
    return res.json({ 
      message: '⏳ Nenhuma doação encontrada...',
      credits: '[Snow](@https://e-z.bio/im_snow)'
    });
  }
});

// Inicia o servidor
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(`Servidor rodando na porta ${PORT}`);
});